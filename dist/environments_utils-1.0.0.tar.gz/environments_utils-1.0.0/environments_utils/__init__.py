from .is_notebook import is_notebook
from .is_tmux import is_tmux


__all__ = ["is_notebook", "is_tmux"]
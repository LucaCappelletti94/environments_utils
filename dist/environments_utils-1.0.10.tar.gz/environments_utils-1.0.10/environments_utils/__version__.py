"""Current version of package environments_utils"""
__version__ = "1.0.10"
